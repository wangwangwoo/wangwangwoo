from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
 
def generate_launch_description():

    rviz_config = LaunchConfiguration('rviz')

    # Gazebo server (gzserver)
    gzserver_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzserver.launch.py'
            ])
        ]),
        launch_arguments={
            'world': PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'worlds',
                'empty.world'
            ])
        }.items()
    )

    # Gazebo client (gzclient)
    gzclient_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzclient.launch.py'
            ])
        ])
    )

    # Spawn robot
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'my_robot',
            '-file', PathJoinSubstitution([
                FindPackageShare('my_robot_gazebo_rviz'),
                'my_robot',
                'model.sdf'
            ]),
            '-x', '0', '-y', '0', '-z', '0.1'
        ],
        output='screen'
    )
    
    # Robot State Publisher (key fixed!)
    urdf_path = PathJoinSubstitution([
        FindPackageShare('my_robot_gazebo_rviz'),  # fix package name!
        'urdf',
        'my_robot.urdf'
    ])
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        arguments=[urdf_path]  # send path !
    )
    
    # RViz2
    rviz_config_file = PathJoinSubstitution([
        FindPackageShare('my_robot_gazebo_rviz'),  # fix package name!
        'config',
        'my_robot.rviz'
    ])
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_file],
        output='screen',
        condition=IfCondition(rviz_config)  # using configure file!
    )
    # 轨迹发布器：将 /odom 转为 /path
    odom_to_path_node = Node(
        package='my_robot_gazebo_rviz',
        executable='odom_to_path',
        name='odom_to_path',
        output='screen',
        parameters=[{
            'odom_topic': '/odom',
            'path_topic': '/path',
            'frame_id': 'odom',
            'max_path_length': 1000  # 可设为 -1 表示不限制
        }]
    )
    return LaunchDescription([
        DeclareLaunchArgument(
            'rviz',
            default_value='true',
            description='Open RViz2'
        ),                      #新增
        gzserver_launch,
        gzclient_launch,
        robot_state_publisher,      #新增
        spawn_entity,
        odom_to_path_node,
        rviz_node,                  #新增

    ])
