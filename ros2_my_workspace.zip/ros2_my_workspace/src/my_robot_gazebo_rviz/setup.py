from setuptools import find_packages,setup
import os
from glob import glob

package_name = 'my_robot_gazebo_rviz'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # install launch file
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        # install model file
        (os.path.join('share', package_name, 'my_robot'), glob('my_robot/**/*', recursive=True)),
        # install world file
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.world')), 
        # ... 原有 launch/worlds ...
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*.urdf')),
        (os.path.join('share', package_name, 'config'), glob('config/*.rviz')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='yahboom',
    maintainer_email='yahboom@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'odom_to_path = my_robot_gazebo_rviz.odom_to_path:main',  # ← 添加这行
            'odom_raw_to_path = my_robot_gazebo_rviz.odom_raw_to_path:main',   # when using /odom_raw topic !
        ],
    },
)

