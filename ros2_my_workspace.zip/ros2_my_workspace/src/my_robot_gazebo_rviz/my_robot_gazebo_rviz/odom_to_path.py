#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import PoseStamped
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
class OdomToPath(Node):
    def __init__(self):
        super().__init__('odom_to_path')
        # 声明参数
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('path_topic', '/path')
        self.declare_parameter('frame_id', 'odom')
        self.declare_parameter('max_path_length', 1000)
        # 获取参数
        odom_topic = self.get_parameter('odom_topic').value
        path_topic = self.get_parameter('path_topic').value
        self.frame_id = self.get_parameter('frame_id').value
        self.max_path_length = self.get_parameter('max_path_length').value
        # 创建发布者和订阅者
        qos_profile = QoSProfile(
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10
        )
        self.path_pub = self.create_publisher(Path, path_topic, qos_profile)
        self.odom_sub = self.create_subscription(Odometry, odom_topic, self.odom_callback, qos_profile)
        self.path = Path()
        self.path.header.frame_id = self.frame_id
        self.get_logger().info(f'odom_to_path: Subscribing to {odom_topic}, publishing path to {path_topic}')
    def odom_callback(self, msg):
        pose = PoseStamped()
        pose.header = msg.header
        pose.pose = msg.pose.pose
        # 强制设置 frame_id（有时 odom 的 header.frame_id 为空）
        pose.header.frame_id = self.frame_id
        self.path.poses.append(pose)
        # 限制轨迹长度
        if self.max_path_length > 0 and len(self.path.poses) > self.max_path_length:
            self.path.poses = self.path.poses[-self.max_path_length:]
        # 更新 header 时间戳
        self.path.header.stamp = self.get_clock().now().to_msg()
        # 发布轨迹
        self.path_pub.publish(self.path)
def main(args=None):
    rclpy.init(args=args)
    node = OdomToPath()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
if __name__ == '__main__':
    main()

