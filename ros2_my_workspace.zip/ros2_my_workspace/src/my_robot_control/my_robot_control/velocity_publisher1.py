#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time

class VelocityPublisher(Node):
    def __init__(self):
        super().__init__('velocity_publisher')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # 等待发布者建立连接
        time.sleep(1)
        
        self.execute_sequence()
    
    def execute_sequence(self):
        """执行4次速度发布序列"""
        steps = [
            # (linear_x, angular_z, duration, description)
            (0.2513, 0.0, 2.0, "Moving forward"),
            (0.2513, 1.25637, 2.5, "Turning 180 degrees"), 
            (0.2513, 0.0, 2.0, "Moving forward again"),
            (0.2513, 1.25637, 2.5, "Turning 180 degrees again")
        ]
        
        for i, (linear_x, angular_z, duration, description) in enumerate(steps):
            self.get_logger().info(f'Step {i+1}: {description}')
            
            # 发布速度指令（类似你的 --once 命令）
            twist_msg = Twist()
            twist_msg.linear.x = linear_x
            twist_msg.linear.y = 0.0
            twist_msg.linear.z = 0.0
            twist_msg.angular.x = 0.0
            twist_msg.angular.y = 0.0
            twist_msg.angular.z = angular_z
            
            self.publisher_.publish(twist_msg)
            self.get_logger().info(f'Published: linear.x={linear_x}, angular.z={angular_z}')
            
            # 等待指定时间
            if i < len(steps):  # 不是最后一步就等待
                time.sleep(duration)
        
        # 发布停止指令
        stop_msg = Twist()
        self.publisher_.publish(stop_msg)
        self.get_logger().info('All steps completed! Publishing stop command.')
        
        # 节点自动退出
        self.destroy_node()
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    velocity_publisher = VelocityPublisher()
