from setuptools import find_packages,setup
import os
from glob import glob

package_name = 'my_robot_gazebo'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # install launch file
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        # install model file
        (os.path.join('share', package_name, 'my_robot'), glob('my_robot/**/*', recursive=True)),
        # install world file
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.world')),        
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='yahboom',
    maintainer_email='yahboom@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        ],
    },
)

